﻿using UnityEngine;

[CreateAssetMenu(fileName = "New equipment", menuName = "Inventory/Equipment")]
public class EquipmentItem : Item
{

    public EquipmentSlotType equipSlot;

    public int damageModifier;
    public int armorModifier;
    public int speedModifier;
    public GameObject prefab;

    public override void Use(Player player)
    {
        player.inventory.RemoveItem(this);
        EquipmentItem oldItem = player.equipment.EquipItem(this);
        if (oldItem != null) player.inventory.AddItem(oldItem);
        base.Use(player);
        //player.equipment.EquipHolder(equipSlot, prefab); // Это здесь пока не нужно... переделываю
    }
}

public enum EquipmentSlotType { Head, Chest, Legs, RighHand, LeftHand }
